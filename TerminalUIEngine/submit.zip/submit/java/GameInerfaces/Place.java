package GameInerfaces;

public interface Place {
    
}
