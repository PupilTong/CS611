package GameItems;

public class Sorcerer extends Hero {

    public Sorcerer(String name, int startmana, int sstrgenth, int sagility, int sdexterity, int smoney, int startexp) {
        super(name, startmana, sstrgenth, sagility, sdexterity, smoney, startexp, Hero.SORCERER_STRING);
    }
    
}
