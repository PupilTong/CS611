package GameItems;

public class Palandin extends Hero {

    public Palandin(String name, int startmana, int sstrgenth, int sagility, int sdexterity, int smoney, int startexp) {
        super(name, startmana, sstrgenth, sagility, sdexterity, smoney, startexp, Hero.PALADINS_STRING);
    }
    
}
