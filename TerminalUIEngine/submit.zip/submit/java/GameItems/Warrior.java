package GameItems;

public class Warrior extends Hero {

    public Warrior(String name, int startmana, int sstrgenth, int sagility, int sdexterity, int smoney, int startexp) {
        super(name, startmana, sstrgenth, sagility, sdexterity, smoney, startexp, Hero.WARRIOR_STRING);
    }
}
