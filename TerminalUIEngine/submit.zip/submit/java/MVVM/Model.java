package MVVM;

/**
 * Model for MVVM partten
 */
public interface Model {
}
