package Models;

public class ReportPageModel {
    
}
