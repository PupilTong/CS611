package Models;

import MVVM.Model;

public class MainPageModel implements Model {
    
}
