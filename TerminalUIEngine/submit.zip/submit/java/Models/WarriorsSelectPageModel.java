package Models;

public class WarriorsSelectPageModel {
    
}
