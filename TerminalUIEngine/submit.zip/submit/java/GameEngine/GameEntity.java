package GameEngine;

public interface GameEntity {
    void onNewRound();
}
